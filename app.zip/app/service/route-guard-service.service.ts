// import { Injectable } from '@angular/core';
// import { CanActivate } from '@angular/router';

// @Injectable({
//   providedIn: 'root'
// })
// export class RouteGuardServiceService implements CanActivate {

//   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
//     return true;
//   }

//   constructor() { }
// }
