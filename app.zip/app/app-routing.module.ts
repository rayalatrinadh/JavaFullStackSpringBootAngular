import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { ListTodosComponent } from './list-todos/list-todos.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  //need to add path for every component to navigate to the required component
  {path : '',component : LoginComponent},
  {path :'login',component : LoginComponent},
  {path : 'welcome/:name', component : WelcomeComponent},  //passing params welcome/:name
  {path : 'todos', component : ListTodosComponent},
  {path: 'logout', component : LogoutComponent},


  {path: '**', component : ErrorComponent} //note by trinadh : error path should be at  ** last** 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
