import { Component } from '@angular/core';


@Component({
  selector: 'app-test-trinadh',
  templateUrl: './test-trinadh.component.html',
  styleUrls: ['./test-trinadh.component.css']
})
export class TestTrinadhComponent {

}
