import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

//import {AppComponent} from '../app.component'

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
//export is like a public modifier in java 
//created a welcome component 
export class WelcomeComponent implements OnInit{
  
  //declare component variables with initialization.
  message : string = "hello trinadh how are you";
  name = '';


//constructon
//in angular constructor variables available at component level. no need to declare local
  constructor(private route : Router,private route1 : ActivatedRoute){


  }

  // ngOnInit():void{}
  ngOnInit() {  
    console.log(this.message);
    this.name =  this.route1.snapshot.params['name']
    console.log('name : ' ,this.name)
  }


  // goHome(){
  //       this.route.navigate(['login'])
  // }


}

//if you want, u can create n number of classes 
export class Test1{

}

export class Test2{


}

export class Test3{

}

export class Test4{


}
